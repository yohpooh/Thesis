package com.example.a31b;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class em_call_accepted extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.em_call_duration);
    }
}