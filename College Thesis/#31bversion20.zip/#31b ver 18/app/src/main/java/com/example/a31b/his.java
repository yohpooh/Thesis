package com.example.a31b;

public class his {

    String Date_Filed, Reference_Number, username;

    public String getDate_Filed() {
        return Date_Filed;
    }

    public String getReference_Number() {
        return Reference_Number;
    }

   /* public String getUsername() {
        return username;
    }*/
}
