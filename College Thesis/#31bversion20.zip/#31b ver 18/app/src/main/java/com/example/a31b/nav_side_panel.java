package com.example.a31b;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class nav_side_panel extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_side_panel1);
    }
}